# Sistema-Bancario-com-Python
Este é o desafio do Bootcamp do DIO cujo tema é "Criando um Sistema Bancário com Python".
Onde a intenção do código é implementar três operações: depósito, saque e extrato para um banco que deseja monetizar suas operações em Python.
